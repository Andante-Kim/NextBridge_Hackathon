# jobs/templatetags/custom_filters.py
from django import template

register = template.Library()

@register.filter
def display_recruit_conditions(value):
    """모집 조건을 리스트 형태로 출력하는 커스텀 필터"""
    if isinstance(value, dict):
        # 딕셔너리를 HTML 리스트 형태로 변환
        return f"<ul>{''.join([f'<li><strong>{k}</strong>: {v}</li>' for k, v in value.items()])}</ul>"
    elif isinstance(value, list):
        # 리스트를 HTML 리스트 형태로 변환
        return f"<ul>{''.join([f'<li>{v}</li>' for v in value])}</ul>"
    else:
        return value
