from django.shortcuts import render, get_object_or_404
from reviews.models import Review

def index(request):
    return render(request, 'reviews/review_main.html')

def review_list(request):
    review_list = Review.objects.order_by('-create_date')
    context = {
        'review_list': review_list,
        'range': range(1, 6),  # 1부터 5까지 반복
    }
    return render(request, 'reviews/review_list.html', context)

# 리뷰 상세보기
def review_detail(request, review_id):
    review = get_object_or_404(Review, pk=review_id)
    context = {
        'review': review,
        'range': range(1, 6),  # 1부터 5까지 반복
    }
    return render(request, 'reviews/review_detail.html', context)

