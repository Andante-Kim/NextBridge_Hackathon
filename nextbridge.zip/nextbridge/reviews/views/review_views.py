from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils import timezone

from jobs.models import JobPosting
from reviews.forms import ReviewForm


# 리뷰 등록(리뷰 저장)
@login_required(login_url='common:login')
def review_create(request, company_id):
    company = get_object_or_404(JobPosting, pk=company_id)
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():                         # 폼이 유효하다면
            review = form.save(commit=False)      # 임시 저장하여 question 객체를 리턴 받는다.
            review.company = company
            review.author = request.user          # author 속성에 로그인 계정 저장
            review.create_date = timezone.now()   # 실제 저장을 위해 작성일시를 설정한다.
            review.save()                         # 데이터를 실제로 저장한다.
            return redirect('company_detail', company_id=company_id)
    else:   # request.method == 'GET'
        form = ReviewForm()
    context = {'form': form, 'company': company}
    return render(request, 'reviews/reviews_form.html', context)
