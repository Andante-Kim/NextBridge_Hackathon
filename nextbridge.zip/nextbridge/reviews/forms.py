from django import forms
from .models import Review

# 리뷰 등록
class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ['subject', 'rating', 'comment']
        labels = {
            'subject': '제목',
            'rating': '별점',
            'comment': '평가',
        }