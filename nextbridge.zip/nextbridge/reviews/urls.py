from django.urls import path
from reviews.views import base_views, review_views

app_name = 'reviews'

urlpatterns = [
    # base_views.py
    path('', base_views.index, name='index'),
    path('list/', base_views.review_list, name='review_list'),
    path('list/<int:review_id>/', base_views.review_detail, name='review_detail'),

    # review_views
]